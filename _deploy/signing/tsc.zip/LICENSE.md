MICROSOFT SOFTWARE LICENSE TERMS

AZURE CODE SIGNING

These license terms are an agreement between you and Microsoft Corporation (or
one of its affiliates). They apply to the software named above and any
Microsoft services or software updates (except to the extent such services or
updates are accompanied by new or additional terms, in which case those
different terms apply prospectively and do not alter your or Microsoft's
rights relating to pre-updated software or services). IF YOU COMPLY WITH THESE
LICENSE TERMS, YOU HAVE THE RIGHTS BELOW. BY USING THE SOFTWARE, YOU ACCEPT
THESE TERMS.

1.  INSTALLATION AND USE RIGHTS.

    a)  General. Subject to the terms of this agreement, you may install and
        use any number of copies of the software to develop and test your
        applications, and solely for use on Windows. You may copy and
        distribute the software (i.e. make available for third parties) solely
        for this purpose.

    b)  Included Microsoft Applications. The software may include other
        Microsoft applications. These license terms apply to those included
        applications, if any, unless other license terms are provided with the
        other Microsoft applications.

    c)  Third Party Components. The software may include third party
        components with separate legal notices or governed by other
        agreements, as may be described in the ThirdPartyNotices file(s)
        accompanying the software.

    d)  Microsoft Services Agreement. Some features of the software provide
        access to, or rely on, online services. The use of those services (but
        not the software) is governed by the separate terms and privacy
        policies in the Microsoft Services Agreement
        https://go.microsoft.com/fwlink/?linkid=398923. Please read them. The
        services may not be available in all regions.

2.  DATA.

    a)  Data Collection. The software may collect information about you and
        your use of the software, and send that to Microsoft. Microsoft may
        use this information to provide services and improve our products and
        services. You may opt-out of many of these scenarios, but not all, as
        described in the product documentation. There are also some features
        in the software that may enable you to collect data from users of your
        applications. If you use these features to enable data collection in
        your applications, you must comply with applicable law, including
        providing appropriate notices to users of your applications. You can
        learn more about data collection and use in the help documentation and
        the privacy statement at https://aka.ms/privacy. Your use of the
        software operates as your consent to these practices.

    b)  Processing of Personal Data. To the extent Microsoft is a processor or
        subprocessor of personal data in connection with the software,
        Microsoft makes the commitments in the European Union General Data
        Protection Regulation Terms of the Online Services Terms to all
        customers effective May 25, 2018, at
        https://docs.microsoft.com/en-us/legal/gdpr.

3.  SCOPE OF LICENSE. The software is licensed, not sold. Microsoft reserves
    all other rights. Unless applicable law gives you more rights despite this
    limitation, you will not (and have no right to):

    a)  work around any technical limitations in the software that only allow
        you to use it in certain ways;

    b)  reverse engineer, decompile or disassemble the software, or otherwise
        attempt to derive the source code for the software, except and to the
        extent required by third party licensing terms governing use of
        certain open source components that may be included in the software;

    c)  remove, minimize, block, or modify any notices of Microsoft or its
        suppliers in the software;

    d)  use the software in any way that is against the law or to create or
        propagate malware; or

    e)  except as expressly stated in Section 1, share, publish, distribute,
        or lease the software, provide the software as a stand-alone offering
        for others to use, or transfer the software or this agreement to any
        third party.

4.  EXPORT RESTRICTIONS. You must comply with all domestic and international
    export laws and regulations that apply to the software, which include
    restrictions on destinations, end users, and end use. For further
    information on export restrictions, visit https://aka.ms/exporting.

5.  SUPPORT SERVICES. Microsoft is not obligated under this agreement to
    provide any support services for the software. Any support provided is
    "as is", "with all faults", and without warranty of any kind.

6.  UPDATES. The software may periodically check for updates, and download and
    install them for you. You may obtain updates only from Microsoft or
    authorized sources. Microsoft may need to update your system to provide
    you with updates. You agree to receive these automatic updates without any
    additional notice. Updates may not include or support all existing
    software features, services, or peripheral devices.

7.  ENTIRE AGREEMENT. This agreement, and any other terms Microsoft may provide
    for supplements, updates, or third-party applications, is the entire
    agreement for the software.

8.  APPLICABLE LAW AND PLACE TO RESOLVE DISPUTES. If you acquired the software
    in the United States or Canada, the laws of the state or province where
    you live (or, if a business, where your principal place of business is
    located) govern the interpretation of this agreement, claims for its
    breach, and all other claims (including consumer protection, unfair
    competition, and tort claims), regardless of conflict of laws principles,
    except that the FAA governs everything related to arbitration. If you
    acquired the software in any other country, its laws apply, except that
    the FAA governs everything related to arbitration. If U.S. federal
    jurisdiction exists, you and Microsoft consent to exclusive jurisdiction
    and venue in the federal court in King County, Washington for all disputes
    heard in court (excluding arbitration). If not, you and Microsoft consent
    to exclusive jurisdiction and venue in the Superior Court of King County,
    Washington for all disputes heard in court (excluding arbitration).

9.  CONSUMER RIGHTS; REGIONAL VARIATIONS. This agreement describes certain
    legal rights. You may have other rights, including consumer rights, under
    the laws of your state or country. Separate and apart from your
    relationship with Microsoft, you may also have rights with respect to the
    party from which you acquired the software. This agreement does not change
    those other rights if the laws of your state or country do not permit it
    to do so. For example, if you acquired the software in one of the below
    regions, or mandatory country law applies, then the following provisions
    apply to you:

    a)  Australia. You have statutory guarantees under the Australian Consumer
        Law and nothing in this agreement is intended to affect those rights.

    b)  Canada. If you acquired this software in Canada, you may stop
        receiving updates by turning off the automatic update feature,
        disconnecting your device from the Internet (if and when you
        re-connect to the Internet, however, the software will resume checking
        for and installing updates), or uninstalling the software. The product
        documentation, if any, may also specify how to turn off updates for
        your specific device or software.

    c) Germany and Austria.

        i.  Warranty. The properly licensed software will perform
            substantially as described in any Microsoft materials that
            accompany the software. However, Microsoft gives no contractual
            guarantee in relation to the licensed software.

        ii. Limitation of Liability. In case of intentional conduct, gross
            negligence, claims based on the Product Liability Act, as well as,
            in case of death or personal or physical injury, Microsoft is
            liable according to the statutory law.

        Subject to the foregoing clause ii., Microsoft will only be liable for
        slight negligence if Microsoft is in breach of such material
        contractual obligations, the fulfillment of which facilitate the due
        performance of this agreement, the breach of which would endanger the
        purpose of this agreement and the compliance with which a party may
        constantly trust in (so-called "cardinal obligations"). In other cases
        of slight negligence, Microsoft will not be liable for slight
        negligence.

10. DISCLAIMER OF WARRANTY. THE SOFTWARE IS LICENSED "AS IS." YOU BEAR THE
    RISK OF USING IT. MICROSOFT GIVES NO EXPRESS WARRANTIES, GUARANTEES, OR
    CONDITIONS. TO THE EXTENT PERMITTED UNDER APPLICABLE LAWS, MICROSOFT
    EXCLUDES ALL IMPLIED WARRANTIES, INCLUDING MERCHANTABILITY, FITNESS FOR A
    PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

11. LIMITATION ON AND EXCLUSION OF DAMAGES. IF YOU HAVE ANY BASIS FOR
    RECOVERING DAMAGES DESPITE** **THE PRECEDING DISCLAIMER OF WARRANTY, YOU
    CAN RECOVER FROM MICROSOFT AND ITS SUPPLIERS ONLY DIRECT DAMAGES UP TO
    U.S. $5.00. YOU CANNOT RECOVER ANY OTHER DAMAGES, INCLUDING CONSEQUENTIAL,
    LOST PROFITS, SPECIAL, INDIRECT, OR INCIDENTAL DAMAGES.

    This limitation applies to (a) anything related to the software, services,
    content (including code) on third party Internet sites, or third party
    applications; and (b) claims for breach of contract, warranty, guarantee,
    or condition; strict liability, negligence, or other tort; or any other
    claim; in each case to the extent permitted by applicable law.

    It also applies even if Microsoft knew or should have known about the
    possibility of the damages. The above limitation or exclusion may not
    apply to you because your state, province, or country may not allow the
    exclusion or limitation of incidental, consequential, or other damages.
